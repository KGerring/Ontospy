
from __future__ import annotations

from html import unescape

from html2txt.parsers import (
    ETreeHTMLParser,
    HTMLParser,
    etreehtmlparser,
    parser,
    xmlfragmentparser
)
from html2txt.parsers.common import escape_html, escape_url
from rdflib import RDF, Graph, Namespace

#blis
#bioregistry
DCAT = Namespace('http://www.w3.org/ns/dcat#')
R3D = Namespace('http://www.re3data.org/schema/3-0#')

SI = 'https://www.w3.org/Consortium/siteindex.html'
specberus = 'https://www.w3.org/pubrules/js/specberus.js'
fixup =     'https://www.w3.org/scripts/TR/2016/fixup.js'
crossref = 'https://www.crossref.org/'
biblio_ui = 'http://www.w3.org/2002/01/tr-automation/tr-biblio-ui'
tr =        'http://www.w3.org/2002/01/tr-automation/tr.rdf'
datacite = 'https://schema.datacite.org/meta/kernel-4.4/metadata.xsd'

bp = 'https://www.w3.org/TR/dwbp/'
bp_s = 'https://www.w3.org/TR/sdw-bp/'
d_bp = 'https://www.w3.org/TR/vocab-dqv/'

SKOS = 'https://www.w3.org/2001/sw/wiki/SKOS'
vc = 'https://w3c.github.io/vc-data-model/'
guide = 'https://www.w3.org/Guide/'


checklink = 'http://validator.w3.org/checklink'
trdoc2rdf = 'http://www.w3.org/2001/10/trdoc2rdf'
tidy = 'http://cgi.w3.org/cgi-bin/tidy'



class dxprof:
	"""
	<a href="#dfn-specification" class="internalDFN" data-link-type="dfn">specifications</a>
	www.w3.org/ns/dx/prof/ResourceRole
	"https://www.w3.org/TR/dx-prof/rdf/prof.ttl"
	http://www.w3.org/ns/dx/prof/profilesont.ttl
	
	
	"""
	dx_prof = 'https://www.w3.org/TR/dx-prof/'
	prof = 'http://www.w3.org/ns/dx/prof/'
	
	
	role = 'http://www.w3.org/ns/dx/prof/role/'
	role_ttl = 'https://www.w3.org/ns/dx/prof/role/index.ttl'
	prof_ttl = 'https://www.w3.org/TR/dx-prof/rdf/prof.ttl'
	
	href="https://www.w3.org/StyleSheets/TR/2016/W3C-WG-NOTE.css"
	ucr = 'https://www.w3.org/TR/dcat-ucr/'
	cr = 'https://github.com/CSIRO-enviro-informatics/prof-ont-implementation-results '
	dcap = 'http://dublincore.org/documents/profile-guidelines/'
	profiles = 'https://w3c.github.io/dxwg/profiles/'
	modspec = 'http://www.opengeospatial.org/standards/modularspec'
	odrl_voc = 'https://www.w3.org/TR/odrl-vocab/'
	#script id="initialUserConfig", type="application/json"
	#wgURI, issueBase, github, localBiblio
#https://w3c.github.io/dxwg/profiles/
#http://www.opengeospatial.org/standards/modularspec
#http://www.opengeospatial.org/standards/cat
#https://doi.org/10.1109/SIIT.2011.6083604

'http://www.w3.org/2002/06/rdfs2html.xsl'

class w3tr:
	scripts = 'https://www.w3.org/scripts'
	std = 'http://www.w3.org/standards/'
	agents = 'http://www.w3.org/standards/agents/'
	types = 'http://www.w3.org/standards/types'
	guide = 'http://www.w3.org/Guide/'
	web_platform_tests = 'https://web-platform-tests.org/'
	tr_automation = 'http://www.w3.org/2002/01/tr-automation'
	tr_pdoc = 'tr-process'
	tr_proc = 'tr-process.n3'
	trdoc_data = 'http://www.w3.org/2001/11/trdoc-data-ts/'
	rec54 = "http://www.w3.org/2001/02pd/rec54#"
	mat = "http://www.w3.org/2002/05/matrix/vocab#"
	tr = 'http://www.w3.org/2001/10/trdoc2rdf.xsl'
	act  = 'https://www.w3.org/TR/tr-activity'
	
	did_core = 'https://www.w3.org/TR/did-core/'
	r3data = 'http://schema.re3data.org/3-1/re3dataV3-1.xsd'
	fdp_s = 'https://w3id.org/fdp/fdp-o#MetadataService'
	atom = 'http://www.w3.org/TR/tr.xml'
	feed = 'http://www.w3.org/blog/news/feed/atom'
	tr = 'http://www.w3.org/2002/01/tr-automation/tr.rdf'
	
	org = "http://www.w3.org/2001/04/roadmap/org#"
	mat = "http://www.w3.org/2002/05/matrix/vocab#"
	doc = "http://www.w3.org/2000/10/swap/pim/doc#"
	contact = "http://www.w3.org/2000/10/swap/pim/contact#"
	ns = "http://www.w3.org/2001/02pd/rec54#"
	proc = "http://www.w3.org/Consortium/Process/"
	pubrules = 'https://www.w3.org/pubrules/'
	
class style:
	rdfs2html = 'http://www.w3.org/2002/06/rdfs2html'
	csv = 'http://dev.w3.org/cvsweb/2004/rdfs2html/rdfs2html.xsl'
	
	
	
	
class opencitations:
	tools = 'http://opencitations.net/tools'
	model = 'http://opencitations.net/model'
	datasets = '/datasets'


'https://www.w3.org/standards/'
