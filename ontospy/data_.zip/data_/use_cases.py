#!/usr/bin/env python
# -*- coding: utf-8 -*-
# filename = use_cases
# author=KGerring
# date = 6/22/22
# project alltypes
# docs root 
"""
 alltypes  

"""
from __future__ import annotations

__all__ = []

import sys  # isort:skip
import os  # isort:skip
import re  # isort:skip

'http://www.w3.org/TR/rdb2rdf-ucr/'

'http://vocab.org/changeset/schema.html'
'http://alistair.cockburn.us/get/2465'
'http://www.w3.org/TR/2009/NOTE-dap-api-reqs-20091015/'
'http://dublincore.org/groups/collections/collection-application-profile/'
'http://dvcs.w3.org/hg/gld/raw-file/default/dcat-ucr/index.html'
'http://dvcs.w3.org/hg/gld/raw-file/default/dcat-ucr/index.html'
#https://www.w3.org/2008/05/xmlspec-diff-generation/



swuc = 'http://www.w3.org/2001/sw/BestPractices/'
pub = 'https://www.w3.org/pubrules/'
pubd = 'https://www.w3.org/pubrules/doc'
nsuri = 'https://www.w3.org/2005/07/13-nsuri'
ew = 'https://github.com/w3c/echidna/wiki'
qas = 'https://www.w3.org/TR/qaframe-spec/'
qah = 'https://www.w3.org/TR/qa-handbook/'
QA = 'https://www.w3.org/QA/WG/qaframe-primer'

frbr = 'http://www.ifla.org/publications/functional-requirements-for-bibliographic-records'
frbr_core = 'http://vocab.org/frbr/core.html'
lld_uc = 'http://www.w3.org/2005/Incubator/lld/XGR-lld-usecase-20111025/'
uc_frags = 'http://www.w3.org/TR/media-frags-reqs'
oslc = 'http://open-services.net/'
powder_uc = 'http://www.w3.org/TR/powder-use-cases/'
rb_rc = 'http://www.w3.org/TR/rdb2rdf-ucr/'







if __name__ == '__main__':
	print(__file__)
