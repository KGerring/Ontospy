


#https://raw.githubusercontent.com/OBOFoundry/OBOFoundry.github.io/master/registry/ontologies.yml
from __future__ import annotations

from collections.abc import Mapping
from typing import (
    TYPE_CHECKING,
    Any,
    Dict,
    Iterable,
    Iterator,
    List,
    Mapping,
    Optional,
    Union
)
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

import datasets
from datasets import (
    SCRIPTS_VERSION,
    config,
    get_dataset_config_info,
    get_dataset_config_names,
    get_dataset_infos,
    get_dataset_split_names,
    load_dataset,
    load_from_disk
)
from datasets.builder import BuilderConfig, DatasetBuilder
from datasets.data_files import (
    DataFilesDict,
    DataFilesList,
    Url,
    _get_data_files_patterns,
    resolve_patterns_in_dataset_repository,
    resolve_patterns_locally_or_by_urls
)
from datasets.features import ClassLabel, Features, Value
from datasets.load import (
    dataset_module_factory,
    import_main_class,
    load_dataset
)
from datasets.packaged_modules import _PACKAGED_DATASETS_MODULES
from datasets.utils.download_manager import DownloadConfig, DownloadManager
from datasets.utils.file_utils import (
    DownloadConfig,
    hash_url_to_filename,
    is_remote_url
)
from fsspec.spec import AbstractBufferedFile, AbstractFileSystem
from requests import ConnectionError, HTTPError, Session
from requests.adapters import BaseAdapter, HTTPAdapter
from requests.models import CaseInsensitiveDict, Response
#from requests.models import Response
from requests.packages.urllib3.util.retry import Retry
from requests_cache.models import (
    AnyPreparedRequest,
    AnyRequest,
    AnyResponse,
    CachedRequest,
    CachedResponse,
    Response
)
from requests_cache.session import CachedSession, CacheMixin
from requests_toolbelt.multipart import MultipartEncoder

#datasets.utils.metadata




class marc:
    url = 'https://www.loc.gov/marc/classification'
    m_class = 'https://www.loc.gov/marc/classification'
    ma_b = 'https://www.loc.gov/marc/bibliographic'
    holdings = 'https://www.loc.gov/marc/holdings'
    community = 'https://www.loc.gov/marc/community'
    ms = 'https://www.loc.gov/marc/specifications/'
    ex = 'https://www.loc.gov/marc/classification/examples.html'
    ecc = 'https://www.loc.gov/marc/classification/eccdmulti.html'
    niso = "http://www.niso.org"
    lang = 'https://www.loc.gov/marc/languages/'
    co = 'https://www.loc.gov/marc/organizations/orgshome.html'
    rel = 'https://www.loc.gov/marc/relators'
    con = 'https://www.loc.gov/marc/concise/'
    bi_l = 'https://www.loc.gov/marc/bibliographic/lite/'
    holdings = 'https://www.loc.gov/marc/holdings/'
    vl = 'https://www.loc.gov/marc/standards/valuelist/'
    sl = 'https://www.loc.gov/marc/standards/sourcelist/'
    marcxml = 'https://www.loc.gov/marcxml'
    mods = 'https://www.loc.gov/mods/'
    mads = 'https://www.loc.gov/standards/mads/'
    

resp = 'https://www.w3.org/Tools/respec/respec-w3c'
'https://www.w3id.org/dpv/primer'


#https://github.com/w3c/respec-web-services/blob/main/static/docs/src.html
#https://github.com/w3c/respec/blob/develop/package.json

#https://github.com/w3c/browser-specs/
#http://github.com/w3c/webref/
#https://www.w3.org/2001/02pd/rec54#

#http://www.w3.org/2001/sw/BestPractices/
#http://lists.w3.org/Archives/Public/spec-prod/

#http://www.w3.org/2004/03/thes-tf/primer/
#http://www.w3.org/TR/swbp-skos-core-guide
#http://www.w3.org/2004/02/skos/core/spec/"


#http://spdx.org/rdf/terms

#https://www.w3.org/TR/dx-prof/rdf/prof.ttl


schemastore = 'https://json.schemastore.org/schema-catalog.json'
# https://json.schemastore.org/schema-catalog.json

dbp_defs = "http://dbpedia.org/ontology/data/definitions.ttl"
dbo = "http://dbpedia.org/ontology/"
#http://mappings.dbpedia.org/index.php/OntologyProperty:


ns1 = 'http://www.openlinksw.com/'
ns5 = 'http://dbpedia.org/ontology/School/'
ads_xsl = 'https://www.loc.gov/standards/mads/v2/mads-2-1.xsd'


cwl = 'https://w3id.org/cwl/view'
#http://xlime-project.org/vocab/

wsdl_rdf = 'http://www.w3.org/ns/wsdl-rdf#'

solid = 'http://www.w3.org/ns/solid/terms#'
r2rml = 'http://www.w3.org/ns/r2rml#'
#http://www.w3.org/ns/odrl/2/  #http://www.w3.org/ns/odrl/2/ODRL22.ttl
ontolex = 'http://www.w3.org/ns/lemon/ontolex#'
ldp= 'http://www.w3.org/ns/ldp#'
dprof = 'https://www.w3.org/TR/dx-prof/rdf/prof.ttl'
uwa = 'http://www.w3.org/2007/uwa/context/common.owl#'
#http://www.w3.org/2006/gen/ont#
#http://www.w3.org/2005/11/its/rdf#
#http://www.w3.org/2005/01/wf/flow#
#http://www.w3.org/2005/01/wai-rdf/GUIRoleTaxonomy#
#http://www.w3.org/2003/g/data-view#
p3prdfv1 = 'http://www.w3.org/2002/01/p3prdfv1#'
bookmark = 'http://www.w3.org/2002/01/bookmark#'
annotation_ns = 'http://www.w3.org/2000/10/annotation-ns#'

#http://www.re3data.org/schema/3-0#

rda = 'http://www.rdaregistry.info/'
bk = provbook = 'http://www.provbook.org/ns/#'
#http://www.openlinksw.com/virtrdf-data-formats#

#http://www.ontotext.com/owlim/lucene#
#http://www.lido-schema.org/
#http://www.bigdata.com/rdf#
#http://wiktionary.dbpedia.org/terms/
#http://wikipedia.no/rdf/
#http://wifo-ravensburg.de/semanticweb.rdf#

#http://lov.okfn.org/dataset/lov
metadataregistry = 'http://metadataregistry.org/vocabulary/list.html'


nkos = 'http://w3id.org/nkos#'
nkos_rdf = 'http://nkos.dublincore.org/nkos.rdf'
nkostype = 'http://nkos.dublincore.org/nkostype/nkostype.rdf'
lov = 'http://lov.okfn.org/dataset/lov'


#http://w3id.org/biolink/vocab/

getty = 'http://vocab.getty.edu/ontology#'
#http://vivoweb.org/ontology/core#
# http://usefulinc.com/ns/doap#    #Project
#https://lov.linkeddata.es/dataset/lov/api/v2/vocabulary/list
#http://topbraid.org/tosh#
#http://swtmp.gitlab.io/vocabulary/templates.owl#
#http://sites.wiwiss.fu-berlin.de/suhl/bizer/d2r-server/config.rdf#
#http://rdvocab.info/roles/
#http://rdf-vocabulary.ddialliance.org/xkos#
#http://purl.org/rss/1.0/modules/content/
#http://purl.org/linked-data/sdmx#

# http://protege.stanford.edu/plugins/owl/dc/protege-dc.owl#
#http://prefix.cc/

evs = 'https://evs.nci.nih.gov/ftp1/rdf/Thesaurus.owl'

#http://lexvo.org/ontology#
#http://identifiers.org/


#http://id.loc.gov/vocabulary/relators/
#http://id.loc.gov/vocabulary/iso639-1/
#http://id.loc.gov/vocabulary/graphicMaterials/
#http://edamontology.org/
dcx = 'http://dublincore.org/dcx/'
# http://docs.oasis-open.org/ns/xri/xrd-1.0#
#http://bioentity.io/vocab/
bio2rdf = 'http://bio2rdf.org/core#'
bibliograph = 'http://bibliograph.net/schemas/'
#http://bibframe.org/vocab/        #www.loc.gov/bibframe/implementation,www.loc.gov/bibframe/docs
#https://github.com/lcnetdev/marc2bibframe2
#https://github.com/lcnetdev/bibframe2marc


#http://assemblee-virtuelle.github.io/grands-voisins-v2/thesaurus.ttl#
#https://raw.githubusercontent.com/opencitations/corpus/master/context.json
oc = 'https://w3id.org/oc/corpus/context.json'


#'http://www.w3.org/2001/sw/DataAccess/tests/test-query#'
#https://linkml.github.io/linkml-registry/registry/

#http://www.sparontologies.net/ontologies/fr
#http://bibliontology.com
#http://www.w3.org/ns/oa.ttl
#http://www.openannotation.org/spec/core/
#http://www.openannotation.org/spec/tutorial/
#http://www.w3.org/community/openannotation/wiki/Cookbook

#http://www.openannotation.org/spec
#https://www.w3.org/TR/annotation-model/
#https://www.w3.org/TR/annotation-vocab/
#https://www.w3.org/TR/annotation-protocol/
#https://www.w3.org/TR/annotation-vocabulary/

#https://github.com/sparontologies/cito
#http://purl.org/spar/cito.ttl
#http://purl.org/spar/cito.json
#https://w3id.org/spar/cito

#https://w3id.org/oc/index/api/v1
#https://w3id.org/oc/index

#https://raw.githubusercontent.com/linkml/linkml/main/linkml/workspaces/datamodel/workspaces.yaml
#https://raw.githubusercontent.com/linkml/linkml/main/linkml/workspaces/datamodel/workspaces.py
#https://specs.frictionlessdata.io/

#http://www.w3.org/ns/csvw#; http://www.w3.org/ns/csvw.jsonld
#http://www.w3.org/TR/tabular-metadata

#https://www.w3.org/2002/01/tr-automation/
#https://id.loc.gov/ontologies/madsrdf/v1.json
mi = 'https://www.dublincore.org/resources/glossary/metadata_interoperability/'
#https://www.dublincore.org/resources/glossary/



#https://www.w3.org/TR/skos-reference/#schemes
skos = 'http://www.w3.org/TR/skos-reference/skos.rdf'
#https://www.loc.gov/standards/mods/modsrdf/v1/modsrdf.owl
#http://www.w3.org/TR/skos-reference/
#http://www.w3.org/2008/05/skos-xl
#http://www.w3.org/TR/skos-ucr
#http://www.w3.org/TR/swbp-vocab-pub/


#http://www.w3.org/2001/sw/DataAccess/tests/test-manifest
#http://www.w3.org/2000/10/rdf-tests/rdfcore/Manifest.rdf

_test="http://www.w3.org/2000/10/rdf-tests/rdfcore/testSchema.rdf"

#https://www.w3.org/Consortium/siteindex.html
#http://www.w3.org/2001/sw/DataAccess/tests/test-dawg#
#ttps://www.dublincore.org/resources/glossary/competency_index/  #https://dcmi.github.io/ldci
#http://prefix.cc/context.jsonld

sru = "http://www.loc.gov/standards/sru/"

ri="http://id.loc.gov/ontologies/RecordInfo.rdf"

#http://www.w3.org/ns/prov.ttl #Activity; http://www.w3.org/ns/prov.owl
#http://id.loc.gov/resources/hubs.rdf
#http://id.loc.gov/resources/instances.rdf
#http://id.loc.gov/resources/works.rdf
#https://lds-downloads.s3.amazonaws.com/vocabulary/relators.skosrdf.jsonld.json

#https://id.loc.gov/vocabulary/relators.skos.json
#https://id.loc.gov/vocabulary/relators.madsrdf.json
#https://id.loc.gov/vocabulary/relators.json
#https://id.loc.gov/vocabulary/marcgt.json
# cs="http://www.w3.org/2003/06/sw-vocab-status/ns#
#https://id.loc.gov/vocabulary/nationalbibschemes.json
#https://id.loc.gov/vocabulary/nationalbibschemes.madsrdf.json
#https://id.loc.gov/vocabulary/nationalbibschemes.skos.json

#http://www.w3.org/2004/02/skos/core#ConceptScheme
#http://id.loc.gov/ontologies/premis.json
#https://id.loc.gov/ontologies/madsrdf/v1.json
#https://id.loc.gov/ontologies/bibframe.json
#https://id.loc.gov/ontologies/bflc.json

#http://id.loc.gov/vocabulary/resourceTypes.json
#https://id.loc.gov/vocabulary/relators.json
#https://id.loc.gov/resources/instances.json

#http://id.loc.gov/authorities/subjects.rdf
#http://id.loc.gov/authorities/subjects
#http://id.loc.gov/authorities/subjects.json

bflc="http://id.loc.gov/ontologies/bflc/"

cs="http://purl.org/vocab/changeset/schema#"
#http://bibliograph.net/schemas/
#http://bio2rdf.org/core#


#http://www.loc.gov/standards/mods/modsrdf/index.html
#http://www.loc.gov/standards/mods/mods.xsd
#http://purl.org/iso25964/DataSet/Versioning#

#http://www.loc.gov/mods/modsrdf/v1/modsrdf.owl
#http://www.loc.gov/standards/mads/rdf/v1.rdf
#http://www.niso.org/schemas/iso25964-resources#26
#http://www.niso.org/schemas/iso25964/schema-intro/
#http://www.niso.org/schemas/iso25964-resources

ldr = 'http://purl.org/linked-data/registry#'

#http://www.w3.org/ns/openannotation/extensions/
#http://www.w3.org/ns/ldp#
